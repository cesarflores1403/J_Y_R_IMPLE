package com.jyr.system.enums;

public enum MovementType {
    ENTRADA,
    SALIDA,
    AJUSTE,
    DEVOLUCION
}
