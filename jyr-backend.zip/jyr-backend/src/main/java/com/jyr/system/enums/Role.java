package com.jyr.system.enums;

public enum Role {
    ADMIN,
    CAJERO,
    BODEGUERO
}
