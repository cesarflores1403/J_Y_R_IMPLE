package com.jyr.system.enums;

public enum ReturnStatus {
    SOLICITADA,
    APROBADA,
    RECHAZADA,
    COMPLETADA
}
