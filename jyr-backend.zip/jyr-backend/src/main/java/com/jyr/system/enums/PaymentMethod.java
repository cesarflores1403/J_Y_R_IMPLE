package com.jyr.system.enums;

public enum PaymentMethod {
    EFECTIVO,
    TARJETA,
    TRANSFERENCIA,
    CREDITO
}
