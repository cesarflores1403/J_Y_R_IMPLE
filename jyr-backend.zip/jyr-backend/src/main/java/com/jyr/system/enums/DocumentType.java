package com.jyr.system.enums;

public enum DocumentType {
    FACTURA,
    COTIZACION
}
