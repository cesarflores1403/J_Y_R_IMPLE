package com.jyr.system.enums;

public enum DocumentStatus {
    PENDIENTE,
    PAGADA,
    ANULADA,
    VENCIDA
}
