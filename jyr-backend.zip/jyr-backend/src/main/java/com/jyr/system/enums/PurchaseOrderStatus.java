package com.jyr.system.enums;

public enum PurchaseOrderStatus {
    PENDIENTE,
    RECIBIDA,
    PARCIAL,
    CANCELADA
}
